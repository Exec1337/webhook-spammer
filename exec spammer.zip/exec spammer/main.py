import time
import requests
import pyfiglet
import fade
import pystyle
from pystyle import *
import colorama
from colorama import Fore
import os

System.Size(80,24)
os.system('title Exec Webhook Spammer ^| discord.gg/execv2')
logo = """
                      ███████╗██╗  ██╗███████╗ ██████╗
                      ██╔════╝╚██╗██╔╝██╔════╝██╔════╝
                      █████╗   ╚███╔╝ █████╗  ██║     
                      ██╔══╝   ██╔██╗ ██╔══╝  ██║     
                      ███████╗██╔╝ ██╗███████╗╚██████╗
                      ╚══════╝╚═╝  ╚═╝╚══════╝ ╚═════╝
                                
"""
fade_logo = fade.water(logo)
print(fade_logo)
msg = input("Message: ")
webhook = input("Webhook: ")
def spam(msg, webhook):
    while True:
        try:
            data = requests.post(webhook, json={'content': msg})
            if data.status_code == 204:
                print(f"Message envoyé -> {msg}")
        except:
            print("Webhook invalide :" + webhook)
            time.sleep(2)
            exit()
kingman_top = 1
while kingman_top == 1:
    spam(msg, webhook)